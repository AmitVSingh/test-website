---
date: "2018-09-09T00:00:00+02:00"
draft: false
linktitle: Example Page
menu:
  tutorial:
    parent: Example Topic
    weight: 1
title: Example Page
toc: true
type: docs
---

In this tutorial, I'll share my top 10 tips for getting started with Academic:

## Tip 1

...

## Tip 2

...
