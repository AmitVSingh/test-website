---
abstract: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis posuere tellus
  ac convallis placerat. Proin tincidunt magna sed ex sollicitudin condimentum. Sed
  ac faucibus dolor, scelerisque sollicitudin nisi. Cras purus urna, suscipit quis
  sapien eu, pulvinar tempor diam. Quisque risus orci, mollis id ante sit amet, gravida
  egestas nisl. Sed ac tempus magna. Proin in dui enim. Donec condimentum, sem id
  dapibus fringilla, tellus enim condimentum arcu, nec volutpat est felis vel metus.
  Vestibulum sit amet erat at nulla eleifend gravida.
authors:
- admin
- Robert Ford
date: "2013-07-01T00:00:00+02:00"
doi: ""
featured: true
image:
  caption: 'Image credit: [**Unsplash**](https://unsplash.com/photos/pLCdAaMFLTE)'
  focal_point: ""
links:
- name: Custom Link
  url: http://example.org
projects:
- internal-project
publication: In *Source Themes Conference*
publication_short: In *STC*
publication_types:
- "1"
slides: example
summary: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis posuere tellus
  ac convallis placerat. Proin tincidunt magna sed ex sollicitudin condimentum.
tags:
- Source Themes
title: An example conference paper
url_code: '#'
url_dataset: '#'
url_pdf: http://eprints.soton.ac.uk/352095/1/Cushen-IMV2013.pdf
url_poster: '#'
url_project: ""
url_slides: ""
url_source: '#'
url_video: '#'
---

{{% alert note %}}
Supplementary notes can be added here, including [code and math](https://sourcethemes.com/academic/docs/writing-markdown-latex/).
{{% /alert %}}
